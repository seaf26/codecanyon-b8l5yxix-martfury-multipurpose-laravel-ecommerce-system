{!! Html::link($href, trans('core/table::table.delete'), ['class' => 'delete-many-entry-trigger', 'data-class-item' => $data_class]) !!}
