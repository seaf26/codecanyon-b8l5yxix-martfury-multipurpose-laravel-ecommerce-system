<?php

namespace Botble\Chart\Supports;

class ChartTypes
{
    public const LINE = 'Line';
    public const BAR = 'Bar';
    public const DONUT = 'Donut';
    public const AREA = 'Area';
}
